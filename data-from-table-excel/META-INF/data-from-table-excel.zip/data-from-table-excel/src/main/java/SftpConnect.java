

import java.security.Key;

import sun.security.pkcs.PKCS7;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;

import java.io.BufferedInputStream;

import java.io.BufferedOutputStream;

import java.io.File;

import java.io.FileInputStream;

import java.io.FileOutputStream;

import java.io .OutputStream;

import com.jcraft.jsch.Channel;

import com.jcraft.jsch.ChannelSftp;

import com.jcraft.jsch.JSch;

import com.jcraft.jsch.Session;

public class SftpConnect {


		public void send (String fileName) {
		    String SFTPHOST = "192.168.40.18";
		    int SFTPPORT = 22;
		    String SFTPUSER = "mwappadmin";
		    String SFTPPASS = "Mwapp@123";
		    //String SFTPWORKINGDIR = "/opt/midd/keystore/";
		    String localFile = "C:/Users/sankeerth.gunturu/Desktop/not needed/sample123.csv";
		    String remoteDir = "/opt/midd/keystore/";				 

		    Session session = null;
		    Channel channel = null;
		    ChannelSftp channelSftp = null;
		    System.out.println("preparing the host information for sftp.");

		    try {
		        JSch jsch = new JSch();
		        session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
		        session.setPassword(SFTPPASS);
		        java.util.Properties config = new java.util.Properties();
		        config.put("StrictHostKeyChecking", "no");
		        session.setConfig(config);
		        session.connect();
		        System.out.println("session connected." + session.isConnected());
		        channel = session.openChannel("sftp");	
		        System.out.println("0 " + channel);
		        channel.connect();
		        System.out.println("channel connected." + channel.isConnected());		       
		        channelSftp = (ChannelSftp) channel;
		        System.out.println("1 " + channelSftp);
		       // channelSftp.cd (SFTPWORKINGDIR);
		        System.out.println("2");
		        //File f = new File(fileName);
		        //System.out.println("3 " + f);
		        //System.out.println(new FileInputStream(f));
		        //System.out.println(f.getName());		       	
		         //channelSftp.get("/opt/midd/keystore/identity.jks", "C:/Users/sankeerth.gunturu/Desktop/not needed/identity-local.jks");		        
		        channelSftp.rm("/opt/midd/keystore/sample111.txt");
		        channelSftp.rm("/opt/midd/keystore/mule-deploy.properties");
		       // channelSftp.put(localFile, remoteDir + "sample123.csv");
		        System.out.println("File transfered successfully to host.");
		    } catch (Exception ex) {
		        System.out.println("Exception found while tranfer the response.");
		        ex.printStackTrace();		        
		    } finally {
		        channelSftp.exit();
		        System.out.println("sftp Channel exited.");
		        channel.disconnect();
		        System.out.println("Channel disconnected.");
		        session.disconnect();
		        System.out.println("Host Session disconnected.");
		    }
		} 
		
	}
	
